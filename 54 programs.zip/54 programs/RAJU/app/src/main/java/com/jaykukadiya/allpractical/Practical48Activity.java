package com.rajuvaja.allpractical;

import android.os.Bundle;
import android.os.Environment;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;

public class Practical48Activity extends AppCompatActivity {

    private File targetFile() {
        File dir = getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS);
        return new File(dir, "external_demo.txt");
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_practical48);
        EditText content = findViewById(R.id.content);
        Button write = findViewById(R.id.write);
        Button read = findViewById(R.id.read);
        write.setOnClickListener(v -> {
            File f = targetFile();
            try (FileWriter w = new FileWriter(f)) {
                w.write(content.getText().toString());
                Toast.makeText(this, "Saved to " + f.getAbsolutePath(), Toast.LENGTH_LONG).show();
            } catch (Exception e) {
                Toast.makeText(this, e.getMessage(), Toast.LENGTH_LONG).show();
            }
        });
        read.setOnClickListener(v -> {
            File f = targetFile();
            try (BufferedReader r = new BufferedReader(new FileReader(f))) {
                StringBuilder b = new StringBuilder();
                String line;
                while ((line = r.readLine()) != null) {
                    b.append(line).append('\n');
                }
                content.setText(b.toString().trim());
            } catch (Exception e) {
                Toast.makeText(this, e.getMessage(), Toast.LENGTH_LONG).show();
            }
        });
    }
}
