package com.rajuvaja.allpractical;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class DoctorDbHelper extends SQLiteOpenHelper {

    private static final String DB_NAME = "hospital.db";
    private static final int DB_VERSION = 1;
    public static final String TABLE = "doc_detail";
    public static final String COL_ID = "doc_id";
    public static final String COL_FIRST = "firstname";
    public static final String COL_LAST = "lastname";
    public static final String COL_MOB = "mob";
    public static final String COL_ADD = "add";
    public static final String COL_CITY = "city";
    public static final String COL_SPEC = "specialization";

    public DoctorDbHelper(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE " + TABLE + " (" +
                COL_ID + " TEXT PRIMARY KEY," +
                COL_FIRST + " TEXT," +
                COL_LAST + " TEXT," +
                COL_MOB + " TEXT," +
                COL_ADD + " TEXT," +
                COL_CITY + " TEXT," +
                COL_SPEC + " TEXT" +
                ")");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE);
        onCreate(db);
    }

    public long insertDoctor(String docId, String first, String last, String mob,
 String add, String city, String spec) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues v = new ContentValues();
        v.put(COL_ID, docId);
        v.put(COL_FIRST, first);
        v.put(COL_LAST, last);
        v.put(COL_MOB, mob);
        v.put(COL_ADD, add);
        v.put(COL_CITY, city);
        v.put(COL_SPEC, spec);
        return db.insertWithOnConflict(TABLE, null, v, SQLiteDatabase.CONFLICT_REPLACE);
    }

    @Nullable
    public Cursor findById(String docId) {
        SQLiteDatabase db = getReadableDatabase();
        return db.query(TABLE, null, COL_ID + "=?", new String[]{docId}, null, null, null);
    }
}
