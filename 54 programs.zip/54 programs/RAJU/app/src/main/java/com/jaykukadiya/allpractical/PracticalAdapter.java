package com.rajuvaja.allpractical;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.List;
import java.util.Locale;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class PracticalAdapter extends RecyclerView.Adapter<PracticalAdapter.VH> {

    public interface OnPracticalClick {
        void onClick(@NonNull PracticalLauncher item);
    }

    private final List<PracticalLauncher> items;
    private final OnPracticalClick listener;

    public PracticalAdapter(@NonNull List<PracticalLauncher> items, @NonNull OnPracticalClick listener) {
        this.items = items;
        this.listener = listener;
    }

    @NonNull
    @Override
    public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_practical, parent, false);
        return new VH(v);
    }

    @Override
    public void onBindViewHolder(@NonNull VH holder, int position) {
        PracticalLauncher p = items.get(position);
        holder.title.setText(formatLabel(p.number, p.title));
        holder.itemView.setOnClickListener(v -> listener.onClick(p));
    }

    @Override
    public int getItemCount() {
        return items.size();
    }

    private static String formatLabel(int number, String title) {
        return String.format(Locale.getDefault(), "%02d. %s", number, title);
    }

    static class VH extends RecyclerView.ViewHolder {
        final TextView title;

        VH(@NonNull View itemView) {
            super(itemView);
            title = itemView.findViewById(R.id.title);
        }
    }
}
