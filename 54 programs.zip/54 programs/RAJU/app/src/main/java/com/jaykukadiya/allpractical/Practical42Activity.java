package com.rajuvaja.allpractical;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class Practical42Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_practical42);
        Button start = findViewById(R.id.start);
        Button stop = findViewById(R.id.stop);
        start.setOnClickListener(v -> {
            startService(new Intent(this, DemoService.class));
            Toast.makeText(this, "Service start requested", Toast.LENGTH_SHORT).show();
        });
        stop.setOnClickListener(v -> {
            stopService(new Intent(this, DemoService.class));
            Toast.makeText(this, "Service stop requested", Toast.LENGTH_SHORT).show();
        });
    }
}
