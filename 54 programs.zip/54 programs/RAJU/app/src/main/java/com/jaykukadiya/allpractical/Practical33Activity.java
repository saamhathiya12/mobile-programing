package com.rajuvaja.allpractical;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class Practical33Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_practical33);
        EditText url = findViewById(R.id.url);
        TextView out = findViewById(R.id.out);
        Button show = findViewById(R.id.show);
        show.setOnClickListener(v -> out.setText(url.getText().toString().trim()));
    }
}
