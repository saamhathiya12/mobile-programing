package com.rajuvaja.allpractical;

import android.os.Bundle;
import android.widget.RadioButton;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class Practical16Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_practical16);
        RadioButton radio = findViewById(R.id.radio_demo);
        TextView state = findViewById(R.id.state);
        state.setText(radio.isChecked() ? "Checked" : "Unchecked");
        radio.setOnCheckedChangeListener((buttonView, isChecked) ->
                state.setText(isChecked ? "Checked" : "Unchecked"));
    }
}
