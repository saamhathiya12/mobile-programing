package com.rajuvaja.allpractical;

import android.os.Bundle;
import android.widget.TextView;
import android.widget.ToggleButton;

import androidx.appcompat.app.AppCompatActivity;

public class Practical11Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_practical11);
        ToggleButton toggle = findViewById(R.id.toggle);
        TextView state = findViewById(R.id.state);
        state.setText(toggle.isChecked() ? "On" : "Off");
        toggle.setOnCheckedChangeListener((buttonView, isChecked) ->
                state.setText(isChecked ? "On" : "Off"));
    }
}
