package com.rajuvaja.allpractical;

import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

public class Practical49Activity extends AppCompatActivity {

    private EditText principal;
    private EditText rate;
    private EditText years;
    private TextView result;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_practical49);
        principal = findViewById(R.id.principal);
        rate = findViewById(R.id.rate);
        years = findViewById(R.id.years);
        result = findViewById(R.id.result);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setTitle("Interest calculator");
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_interest, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.action_si) {
            computeSi();
            return true;
        } else if (id == R.id.action_ci) {
            computeCi();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    private void computeSi() {
        try {
            double p = Double.parseDouble(principal.getText().toString().trim());
            double r = Double.parseDouble(rate.getText().toString().trim());
            double t = Double.parseDouble(years.getText().toString().trim());
            double si = p * r * t / 100.0;
            result.setText(getString(R.string.result) + ": " + si);
        } catch (Exception e) {
            Toast.makeText(this, "Check inputs", Toast.LENGTH_SHORT).show();
        }
    }

    private void computeCi() {
        try {
            double p = Double.parseDouble(principal.getText().toString().trim());
            double r = Double.parseDouble(rate.getText().toString().trim());
            double t = Double.parseDouble(years.getText().toString().trim());
            double amt = p * Math.pow(1 + r / 100.0, t);
            double ci = amt - p;
            result.setText(getString(R.string.result) + " (CI): " + ci + " | Amount: " + amt);
        } catch (Exception e) {
            Toast.makeText(this, "Check inputs", Toast.LENGTH_SHORT).show();
        }
    }
}
